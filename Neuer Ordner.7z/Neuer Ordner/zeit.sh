#!/bin/bash
tlsdate -svH google.com
hwclock -w --localtime
